def abc():
    return 123